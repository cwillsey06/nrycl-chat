<div align="center">
	<img src="https://assets.vorlias.com/i1/snapdragon.png"/>

</div>
<div align="center">
  	<h1>Snapdragon</h1>
	<a href="https://www.npmjs.com/package/@rbxts/snapdragon">
		<img src="https://badge.fury.io/js/%40rbxts%2Fsnapdragon.svg"></img>
	</a>
</div>

Library for UI dragging support, with snapping capabilities in Roblox. 