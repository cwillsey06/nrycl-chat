# Parent Constraint
In this example, the draggable GUI is constrained to being dragged inside the parent frame.

This is achieved through `DragRelativeTo = "Parent"` rather than `DragRelativeTo = "LayerCollector"`